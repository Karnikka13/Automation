import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features",
    glue = "stepDefinitions",
    tags = "@history",
    plugin = {"pretty", "html:target/cucumber-reports.html"}
)
public class TestRunner {
    // EMPTY - No code needed
    // We'll control execution via Maven commands
}