@overpayment
Feature: Overpayment screen

  Scenario: Verify overpayment calculation
    Given user is on the Overpayment page
    When user enters overpayment values
    Then system should calculate correct result
