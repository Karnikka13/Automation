package utils;

import org.apache.poi.ss.usermodel.*;
import java.io.FileInputStream;
import java.util.*;

public class ExcelReader {
    public static List<Map<String,String>> readExcelData(String filePath) {
        List<Map<String,String>> rows = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook wb = WorkbookFactory.create(fis)) {

            Sheet sheet = wb.getSheetAt(0);
            Row header = sheet.getRow(0);
            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;
                Map<String,String> map = new HashMap<>();
                for (int c = 0; c < header.getLastCellNum(); c++) {
                    String key = header.getCell(c).getStringCellValue().trim();
                    Cell cell = row.getCell(c);
                    String val = (cell == null) ? "" : cell.toString().trim();
                    map.put(key, val);
                }
                rows.add(map);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to read Excel: " + filePath, e);
        }
        return rows;
    }
}
