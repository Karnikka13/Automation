package stepDefinitions;

import io.cucumber.java.en.*;

public class Overpayment {

    @Given("user is on the Overpayment page")
    public void openPage() {
        System.out.println("Opening Overpayment Page");
    }

    @When("user enters overpayment values")
    public void enterValues() {
        System.out.println("Entering overpayment values");
    }

    @Then("system should calculate correct result")
    public void verifyResult() {
        System.out.println("Checking result");
    }
}
