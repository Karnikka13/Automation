package stepDefinitions;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

public class DriverManager {

    private static WebDriver driver;
    private static WebDriverWait wait;
    private static JavascriptExecutor js;
    private static Actions actions;

    // Private constructor to prevent instantiation
    private DriverManager() { }

    // Returns the singleton WebDriver instance
    public static WebDriver getDriver() {
        if (driver == null) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            js = (JavascriptExecutor) driver;
            actions = new Actions(driver);
        }
        return driver;
    }

    public static WebDriverWait getWait() {
        getDriver(); // ensure driver is initialized
        return wait;
    }

    public static JavascriptExecutor getJS() {
        getDriver();
        return js;
    }

    public static Actions getActions() {
        getDriver();
        return actions;
    }

    // Quit browser and reset everything
    public static void quitDriver() {
        if (driver != null) {
            try {
                driver.quit();
            } catch (WebDriverException e) {
                System.out.println("Failed to quit WebDriver: " + e.getMessage());
            } finally {
                driver = null;
                wait = null;
                js = null;
                actions = null;
            }
        }
    }
}
