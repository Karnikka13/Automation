package runners;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/java/features/Login.feature",
    glue = "stepDefinitions",
    plugin = {"pretty", "html:target/cucumber-reports"},
    tags = "@Login" 
)
public class TestRunner {
}